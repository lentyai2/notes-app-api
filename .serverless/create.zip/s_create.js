
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tfeferman',
  applicationName: 'notes-app-api-app',
  appUid: 'q6zTS8rfmm4wJrfSBX',
  orgUid: 'gXX8kjKH6gkn9hJ394',
  deploymentUid: 'e8132c13-efd0-477c-aef7-14ce0afd8c9e',
  serviceName: 'notes-app-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.15',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'notes-app-api-dev-create', timeout: 6 };

try {
  const userHandler = require('./create.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}